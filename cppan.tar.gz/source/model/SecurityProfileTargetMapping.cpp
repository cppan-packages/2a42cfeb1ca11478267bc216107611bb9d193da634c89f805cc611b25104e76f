﻿/*
* Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
*
* Licensed under the Apache License, Version 2.0 (the "License").
* You may not use this file except in compliance with the License.
* A copy of the License is located at
*
*  http://aws.amazon.com/apache2.0
*
* or in the "license" file accompanying this file. This file is distributed
* on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
* express or implied. See the License for the specific language governing
* permissions and limitations under the License.
*/

#include <aws/iot/model/SecurityProfileTargetMapping.h>
#include <aws/core/utils/json/JsonSerializer.h>

#include <utility>

using namespace Aws::Utils::Json;
using namespace Aws::Utils;

namespace Aws
{
namespace IoT
{
namespace Model
{

SecurityProfileTargetMapping::SecurityProfileTargetMapping() : 
    m_securityProfileIdentifierHasBeenSet(false),
    m_targetHasBeenSet(false)
{
}

SecurityProfileTargetMapping::SecurityProfileTargetMapping(JsonView jsonValue) : 
    m_securityProfileIdentifierHasBeenSet(false),
    m_targetHasBeenSet(false)
{
  *this = jsonValue;
}

SecurityProfileTargetMapping& SecurityProfileTargetMapping::operator =(JsonView jsonValue)
{
  if(jsonValue.ValueExists("securityProfileIdentifier"))
  {
    m_securityProfileIdentifier = jsonValue.GetObject("securityProfileIdentifier");

    m_securityProfileIdentifierHasBeenSet = true;
  }

  if(jsonValue.ValueExists("target"))
  {
    m_target = jsonValue.GetObject("target");

    m_targetHasBeenSet = true;
  }

  return *this;
}

JsonValue SecurityProfileTargetMapping::Jsonize() const
{
  JsonValue payload;

  if(m_securityProfileIdentifierHasBeenSet)
  {
   payload.WithObject("securityProfileIdentifier", m_securityProfileIdentifier.Jsonize());

  }

  if(m_targetHasBeenSet)
  {
   payload.WithObject("target", m_target.Jsonize());

  }

  return payload;
}

} // namespace Model
} // namespace IoT
} // namespace Aws
